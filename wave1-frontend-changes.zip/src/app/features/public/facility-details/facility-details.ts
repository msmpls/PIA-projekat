import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FacilityDetails } from '../../../core/models/facility-details.model';
import { FacilityRatings } from '../../../shared/components/facility-ratings/facility-ratings';

@Component({
  selector: 'app-facility-details',
  standalone: true,
  imports: [CommonModule, RouterLink, FacilityRatings],
  templateUrl: './facility-details.html',
  styleUrl: './facility-details.css',
})
export class FacilityDetails implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private http = inject(HttpClient);

  private apiUrl = 'http://localhost:8080/api/public/facilities';

  details = signal<FacilityDetails | null>(null);
  loading = signal(true);
  error = signal('');
  selectedImage = signal<string>('');

  facilityId = 0;

  ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    this.facilityId = Number(idParam);
    if (!this.facilityId) {
      this.error.set('Neispravan ID objekta.');
      this.loading.set(false);
      return;
    }
    this.loadDetails();
  }

  loadDetails(): void {
    this.loading.set(true);
    this.http.get<FacilityDetails>(`${this.apiUrl}/${this.facilityId}`).subscribe({
      next: (data) => {
        this.details.set(data);
        if (data.galleryImages && data.galleryImages.length > 0) {
          this.selectedImage.set(data.galleryImages[0]);
        }
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Objekat nije pronađen ili nije odobren.');
        this.loading.set(false);
      },
    });
  }

  selectImage(img: string): void {
    this.selectedImage.set(img);
  }

  goBack(): void {
    this.router.navigate(['/search']);
  }
}
