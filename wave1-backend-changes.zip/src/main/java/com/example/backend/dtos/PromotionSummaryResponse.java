package com.example.backend.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * Kratak prikaz promocije za pocetnu stranicu.
 * Sadrzi naziv promocije, naziv objekta, period vazenja i popust.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PromotionSummaryResponse {
    private String promotionName;
    private String facilityName;
    private String city;
    private LocalDate startDate;
    private LocalDate endDate;
    private Integer discountPercent;
}
